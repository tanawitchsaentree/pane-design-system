# pane-react changelog

Every entry names the component it touches, so each component page in the book can show its own history. The conformance run fails if a component has no entry.

## 0.8.5 (2026-11-04)

- RadioCards: the chosen card carries a full ring in the text colour and a lighter fill, so on flat glass it reads apart from the rest at a glance.
- NumberInput: the group hugs minus, the number and plus, so the two buttons sit either side of the value instead of at the far ends of a wide bar.
- Badge: a crystal in dark has a fuller tinted body and a brighter facet along its top edge, so it reads as a piece of glass on the pane.

## 0.8.4 (2026-11-03)

- Button: flat. The loud button is a flat fill and the quiet one a flat tint, with no gloss, top streak, glint or cast shadow, so a white button no longer swells off the glass.
- Card: flat. A pane is one thin sheet with an even hairline rim, with no bevel, top streak or lift shadow. Overlays (levels 3 and 4) keep their shadow.
- Switch: the track and the knob are flat fills; the knob keeps a hairline so it reads on a lit track.
- SegmentedControl: the chosen segment and the track are flat, with no carve or cast.

## 0.8.3 (2026-11-02)

- Environment: materials nest. An Environment with `material` set starts its own world inside another one, so glass, liquid and solid can sit side by side; leave `material` unset and it follows the Environment around it. Solid now ends at a nested Environment of another material, and liquid no longer lenses the panes of a nested one.
- Card: the solid fill stops at a nested Environment of another material.
- NetworkGraph: edge weight moves to CSS (`--edge-weight`), the same width as before.
- ChatMessage: the streaming caret is one line tall.

## 0.8.2 (2026-11-02)

- Button and IconButton toggles, Calendar days, TreeView and DataGrid rows, RichTextEditor tools and Checkbox marks change state smoothly (R-048). A toggle's on-glass is its own layer that fades in, fills move as two registered colours, and the check stays mounted and scales in. RadioCards keeps one shadow layer order, so its shadow moves instead of swapping.
- Menu leaves with an exit, 220ms and accelerating, instead of vanishing (G-MO4), from the new `motion.exit` and `motion.easing-exit` tokens. Under reduced motion it still fades.
- Select's trigger and chevron open on the press rhythm, since the list opens on the press.

## 0.8.1 (2026-11-01)

- SegmentedControl, Switch, RadioCards and ButtonGroup fade into their chosen state (R-048). Each fill is now two registered colours (`--pane-fill-top`, `--pane-fill-foot`), so the browser can move between rest, hover and chosen. Before, a gradient swapped in one frame. The change settles on the press's 300ms way back up. Tabs keeps its sliding indicator.

## 0.8.0 (2026-11-01)

- Chip chooses smoothly (R-048). The chosen fill fades in, the check's track opens so the chip grows and its neighbours glide instead of jumping, and the label keeps room for its heavier weight. All of it settles on the press's 300ms way back up. Under reduced motion the width changes at once and the fade stays.
- Environment takes `look` (D-043): `corner`, `density` and `controls` are the anchor knobs, and every inner corner, media corner, control corner and gap follows them so nesting holds. The same knobs work in plain CSS as `--ds-look-*` on any `[data-look]` element, and any token can still be set after them.

## 0.7.0 (2026-10-30)

- Environment takes `material="liquid"` (R-045). Every glass pane inside bends the scene at its rim and lifts its middle like a lens, from a map built for its own size and corner, with a clearer blur so the bend shows. Chrome and Edge run it, and other browsers show plain glass.
- ActionSheet fades its rows on hover with the hover rhythm, light up in 130ms and fade over 380ms (R-044). Every hover and press in the system now enters fast and leaves slowly, through one token rule, and keeps that rhythm under Reduce motion, where only travel stops.
- A CodeBlock under every live demo now holds the HTML of that demo, with the stable class names from all.css, so a Vue, Svelte, Angular or plain page can copy it (D-042). The tokens also build for Kotlin, Dart, Tailwind and Figma.
- CodeBlock: new. Code in colour from the syntax tokens, every role at 4.5:1 on its code ground, with Copy always in reach, Show all for long files, line numbers and IDE palettes as code themes (GitHub Dark and Light, One Dark, Dracula, Solarized Light) (D-040).
- Card: the glass has volume. A hairline rim lit at the top left and again along the foot where light leaves the slab, a bevel inside (a lit upper lip, a shaded lower one) and a deeper lift (R-041).
- The Badge crystal is clear, with a thin tint lit at the top, a crisp rim and a hairline of the tone at the foot, with no glow around it.
- Chip: a chosen chip with a tone is the same clear crystal as Badge.
- PaneProvider: with reduced motion, hover and press keep a 100ms fade of colour and light while every movement stops (D-039); before, every duration went to 0 and controls snapped.
- IconButton: a swapped glyph, such as play to pause, fades in.
- Navbar: its controls fade on hover like a Button's (D-039).
- Breadcrumb: its controls fade on hover like a Button's (D-039).
- NumberInput: its controls fade on hover like a Button's (D-039).
- PasswordInput: its controls fade on hover like a Button's (D-039).
- SearchInput: its controls fade on hover like a Button's (D-039).
- Stepper: its controls fade on hover like a Button's (D-039).
- TagInput: its controls fade on hover like a Button's (D-039).
- FileUpload: its controls fade on hover like a Button's (D-039).
- ChatComposer: its controls fade on hover like a Button's (D-039).
- Citation: its controls fade on hover like a Button's (D-039).
- Combobox: its controls fade on hover like a Button's (D-039).
- TransferList: its controls fade on hover like a Button's (D-039).
- Wizard: its controls fade on hover like a Button's (D-039).
- DataGrid: its controls fade on hover like a Button's (D-039).
- TableOfContents: its controls fade on hover like a Button's (D-039).
- ButtonGroup: attached buttons sit in one carved track at an even inset, the pressed one as chosen glass, instead of squared inner corners.
- SplitButton: the menu opens under the whole button, lined up with the action's start; the open menu half no longer draws a ring round its squared corner.
- Select: its menu shares the popover layer, so a Select inside a popover opens above it.
- Tabs: the panel stands a group's gap below the tab list.
- CommandPalette: the field's focus ring is drawn inside it, where the palette's corner cannot clip it.
- Menu: `alignOffset` moves the menu along its edge.
- SegmentedControl: `showLabel` puts the label above the track like Select's, and the track is as tall as a field of the same size (44px md, 32px sm), so the two stand level in a row.
- Badge is a small crystal by default (D-038), the tone's tint lit from above with its rim and a coloured glow; `appearance` muted, solid or plain, and a new violet `accent` tone for New, the word without a glyph. A crystal stays a crystal on solid material; solid is chosen by hand.
- Chip: `tone` turns a chosen chip into a crystal of that colour.
- Tag: `tone` puts a thin tint of the tone in the etch.
- CommandPalette: a keycap at the end of a row takes the row's nested corner.
- Card: a pane nested in a pane takes the outer corner minus the padding, so the corners stay concentric.
- Brands given to PaneProvider reach further (D-037). A brand file may also set type weights, display tracking, glass saturation, mesh colours and motion durations, and name a `density` (compact, regular, roomy) and a `motion` tempo (brisk, steady, calm); setting `tier` to `expert` opens every semantic token with the contrast checks kept. Six more sample brands ship: Ledger, Kiddo, Atelier, Pulse, Terra and Signal.
- Mesh: documented as an accent, about a tenth of the region it sits in (D-036); the book's Aurora backdrop and full-width mesh covers are gone, and `check_usage` flags a Mesh used as a background.
- Card: the glass body is thin again (45% in dark, 66% in light, blur 32px), so the scene's colour and shapes show through; on `material="solid"` the body is fully opaque (D-035).
- Tooltip: the same glass recipe as cards (blur, saturate and the environment's dimming).
- Snackbar: the same glass recipe as cards (blur, saturate and the environment's dimming).
- Toast: the same glass recipe as cards (blur, saturate and the environment's dimming).
- IconButton: the same glass recipe as cards (blur, saturate and the environment's dimming).
- Navbar: the bar's glass now saturates and dims the scene like a card, so its labels keep 4.5:1 on bright scenes.
- Sidebar: the same glass recipe as the Navbar and cards.
- BottomNav: the same glass recipe as the Navbar and cards.
- NavigationMenu: the same glass recipe as the Navbar and cards.
- Environment: dims the scene by how bright it is (.70 / .56 / .48) instead of one heavy .42, so glass reads as glass on a photo and on a plain room.
- Environment: `material` (glass or solid) is now the documented way a screen chooses what its panes are made of, with the Materials chapter, Choose your look, and `choose_appearance` in pane-mcp.
- ChatMessage: new. One turn of a conversation, the reader's on chosen glass and the answer as text on the pane, with ChatToolCall steps and a streaming caret.
- ChatComposer: new. A growing field in the field's well with one bead that sends or stops; Enter sends, Shift+Enter is a new line.
- AgentStatus: new. What an AI agent is doing, a glyph and a word per state, its steps and the one action that fits.
- HumanHandoff: new. The move between an assistant and a person, from the offer to the hand back, announced once per change.
- Citation: new. A numbered mark after a claim that opens its source, the passage and a link.
- PaneProvider: white-label brands (D-033). Load `pane-react/tokens/brands/<id>.css` and set `data-brand`; three samples ship (Harbor, Sage, Plum) and `pane-theme check` validates your own.
- IconButton: icons are drawn at their size again (a content wrapper had made them 0×0).
- Pagination: when the whole bar does not fit its space, the numbered pages give way to the page in words between Previous and Next.
- SegmentedControl: stretched by its container, the segments share the track evenly.
- List: sets its own body type instead of taking the page's.
- Sidebar: sets its own body type instead of taking the page's.
- SplitButton: the menu half keeps a 44px press area.
- Mesh: the ground colour is also on the box, under the pools.
- Button: `pressed` makes it a toggle (chosen glass, a ring, aria-pressed); `chevron` draws a chevron that turns while its menu is open; `href` renders it as a link that looks like a button.
- IconButton: `pressed` and `pressedIcon` make it a toggle, such as Favourite.
- ButtonGroup: new. Buttons that belong together, apart or joined with a hairline seam and squared inner corners, in a row or stacked.
- SplitButton: new. The usual action and a chevron that opens its alternatives, two focus stops.
- Input: `clearable` adds a clear button that keeps its place; `showCount` with maxLength shows the count and says it near the limit.
- Textarea: `autoResize` grows with the text up to `maxRows`; `showCount` as Input.
- HelperText: `warning` tone, the triangle glyph and the word Warning.
- FormField: `warning`, a note that does not mark the field invalid.
- Fieldset: `error` for the whole group, such as Choose at least one.
- FileUpload: `status` says where each file's upload has got to (a bar, Uploaded, or the reason and Retry with `onRetry`).
- Progress: `hideLabel` keeps the label for screen readers only.
- RadioCards: `hideLabel`, for a SettingsRow that already shows the words.
- Slider: `hideLabel`, as RadioCards.
- Accordion: an item's title can be any content, such as a heading with a live timer.
- Navbar: a long brand shrinks with an ellipsis on a phone instead of pushing the actions off the edge.
- Mesh: the pool blur scales with the box, so a small swatch keeps its pools.
- InputGroup: read only is drawn on the well, so a read-only PasswordInput or field with adornments no longer shows a second pill inside the first.
- Checkbox: a soft round wash fills the 44px hit area under a pointer.
- Radio: a soft round wash fills the 44px hit area under a pointer.
- Switch: a soft wash fills the hit area around the track under a pointer.
- FAB: rises one step under a pointer.
- Chip: a chip that is a button washes under a pointer.
- Accordion: the header row washes under a pointer; forced colours draw the chevron and focus ring.
- Tabs: `orientation="vertical"` lays the track beside the panel with the sheet sliding down; disabled tabs are dimmed; a tab not chosen comes up to the primary tone under a pointer.
- Textarea: read only drops the groove for a hairline ring, as Input.
- Breadcrumb: forced colours draw the links, the current page and the focus ring.
- Input: the line box is the body leading, so Thai tone marks over upper vowels are no longer cut off (every field built on Input gets it).
- SearchInput: the clear button keeps its place while the field is empty, so typing never widens the field.
- Toast: each tone has its own glyph (the Banner shapes) and its word is read before the title; it swipes towards the end edge in RTL too.
- Table: straight on a scene it blurs and dims what is behind it like a Card, so its rows read on a photo; inside a pane it stays the inner level.
- List: the inset list brings its own glass on a scene, as Table does.
- Listbox: the inline list brings its own glass on a scene, as Table does.
- VirtualList: brings its own glass on a scene, as Table does.
- RadioCards: each card brings its own glass on a scene, as Table does.
- ConfidenceChip: new. How sure a claim is, as dots filled to the level in one sequential hue (D-032) with the level in words.
- NodeCard: new. A step on a canvas with ports, chosen glass when picked, Enter to pick and arrow keys to move it.
- NetworkGraph: new. Nodes and links on a quiet canvas, the neighbourhood in focus lit, arrow keys between nodes and a table of every link.
- SequenceDiagram: new. Messages between actors in lanes, solid for a message and dashed for a reply, spoken step by step.
- Button: `ghost` and `danger` variants, size `lg`, `icon` and `iconEnd`, and `fullWidth`.
- PaneProvider: new. Sets the words and the locale for every component below it; `en` (default) and `th` ship, and a custom catalog is typed as PaneMessages. th-TH gives the Buddhist year.
- Calendar: month names, weekdays and its button names follow PaneProvider's catalog and locale.
- DataGrid: its checkbox names and loading line come from the catalog.
- Pagination: Previous, Next and Page n come from the catalog.
- OTPFlow: every line it shows or announces comes from the catalog.
- MultiSelect: a chip's remove button no longer says Remove twice.
- TagInput: a tag's remove button no longer says Remove twice.
- Scale: new. A position on a short ordered scale, the slider channel cut into steps with a bead, a ring to compare with and a band between them; also as plain HTML with pane-scale.css.
- RadarChart: new. A profile over a few axes as one 2px shape per series with a faint wash, a table view and arrow keys between axes.
- Button: `loading` keeps the width and focus, shows a spinner, says it is busy and ignores presses.
- IconButton: `loading`, as Button's.
- Checkbox: `invalid`, a critical ring and aria-invalid; FormField's error sets it.
- Radio: RadioGroup takes `invalid`, ringing every circle.
- Switch: `invalid`, as Checkbox's.
- RadioCards: `invalid` and `disabled` for the whole group.
- Listbox: `disabled` and `invalid`; FormField sets both.
- SegmentedControl: `disabled`.
- ColorPicker: `disabled`, for the swatches and the hex field.
- Rating: `disabled`.
- Chip: `disabled` dims the pill and turns off both of its buttons.
- FAB: a disabled FAB dims and refuses presses.
- Select: `readOnly` and `invalid`; FormField's disabled and required now reach it.
- Combobox: `disabled`, `readOnly`, `invalid` and `required`.
- Autocomplete: `disabled`, `readOnly`, `invalid` and `required`.
- MultiSelect: `disabled`, `readOnly`, `invalid` and `required`; read-only chips have no remove button.
- TagInput: `disabled`, `readOnly`, `invalid` and `required`.
- DatePicker: `readOnly` and `invalid`; FormField's required reaches it.
- TimePicker: `readOnly`.
- PinInput: `readOnly`; FormField's required reaches every cell.
- RichTextEditor: `readOnly` and `invalid`; FormField's disabled and required reach it.
- NumberInput: FormField's disabled now turns off the steppers too.
- InputGroup: a disabled field dims the whole well once.
- Editable: disabled text is set in the secondary tone.
- Table: `loading` and `empty`.
- DataGrid: `empty`.
- FileUpload: `invalid`.
- Dropzone: `invalid`.
- Box: new. Padding and a corner from the scales, nothing else.
- Flex: new. A row or column with a gap from the scale and both alignments named.
- Center: new. Content in the middle of the space it is given.
- Spacer: new. A fixed step from the gap scale, or the free space in a row.
- Divider: new. A hairline groove etched into the glass, shade over light; horizontal or vertical, optionally inset.
- AspectRatio: new. square, photo, video, portrait or wide at any width.
- VisuallyHidden: new. Text for screen readers only; `focusable` brings a skip link back into view.
- Text: new. Text at a step of the type scale (reading, body, label, caption, micro) in one of two tones and three weights; `truncate` for one line.
- Heading: new. The level from the outline, the size from the scale.
- Icon: new. A glyph at 16 or 18px in the text colour; decorative unless it has a `label`.
- Link: new. Found by its underline in the text colour (no hue); `standalone` and `external`.
- Spinner: new. A lit arc turning in a groove, with a status role and a label; still under reduced motion.
- Skeleton: new. Text lines, a block or a circle carved into the glass, breathing slowly.
- Kbd: new. A key as a small keycap lit from above.
- Listbox: new. Options kept on the page in a recess, one or several (`multiple`), with checks.
- Combobox: new. A groove that filters a long list as you type, on the WAI-ARIA combobox pattern.
- Autocomplete: new. Suggestions with free text.
- MultiSelect: new. Several values from a long list, each a removable Chip.
- Menu: new. Actions from a button in Select’s sheet, grouped, the critical one last.
- ContextMenu: new. The Menu sheet on a right click, a long press or the menu key.
- RadioCards: new. One choice as level-2 cards, chosen glass with a check.
- Rating: new. Stars in the loud solid and outlines; `readOnly` reads as “4 out of 5”.
- TagInput: new. Free-form tags as chips; Enter or a comma adds, Backspace removes.
- SegmentedControl: new. Two to five views of the same content on a short glass track; one tab stop, arrows move.
- BottomNav: new. The dock of three to five places at the foot of a phone screen, the current one raised.
- Navbar: new. The header with the brand, the main sections and one or two actions; sticky by default.
- Sidebar: new. Grouped destinations in a column, with counts and an optional header and footer.
- Breadcrumb: new. The path to the page, the current step announced and never a link.
- Pagination: new. Previous, the pages around the current one and Next, with an ellipsis for the gaps.
- Stepper: new. Done, current and upcoming steps of one task, horizontal or vertical.
- Accordion: new. Sections opened by their headings, one at a time or several.
- NavigationMenu: new. Site sections in a row, some opening a panel of links; Esc returns focus.
- TableOfContents: new. The sections of a long page, tracking the one in view.
- Progress: new. How far a task has come, in the slider's channel with the loud fill; with no value it travels.
- Meter: new. A reading inside a range; a high one adds a triangle and Almost full, a full one a diamond and Full.
- Stat: new. One number said large, with its change as an arrow and words, and a sentiment apart from its direction.
- EmptyState: new. A glyph in a carved well, a title, one sentence and the way out.
- Timeline: new. Events on a hairline rail; done, current and upcoming dots differ by shape.
- DescriptionList: new. Term and detail pairs in a real dl, stacked or inline, with optional dividers.
- List: new. Rows of one kind, inset on a level-2 pane or plain; ListItem rows can be links or buttons.
- Table: new. A captioned table with a sticky opaque header, sortable headers with aria-sort and two densities.
- PasswordInput: new. Input's groove with a show button that says its state; it hides again on submit.
- SearchInput: new. A search landmark with a magnifier and a clear button; Enter searches and Esc clears.
- NumberInput: new. A spinbutton with minus and plus in one groove, held to its limits when the field is left.
- RangeSlider: new. Slider's channel with two beads, each named for its end; the two never cross.
- Editable: new. Text that turns into the groove where it stands; Enter saves and Esc puts the words back.
- FileUpload: new. A button and a list of chosen files with sizes and remove buttons; refusals are said in words.
- Dropzone: new. A large carved well that takes dragged files and is a button for the chooser.
- ColorPicker: new. Named swatches as radios, with an optional hex field, for the content's own colours.
- OTPFlow: new. PinInput with where the code went, the check, the error in words and a resend countdown.
- Calendar: new. A month of round 44px days in a grid; today ringed, the chosen day the loud solid, a range a band of chosen glass.
- DatePicker: new. Select's groove opening Calendar on a level-4 popover; single days or a stay, focus back on the field.
- TimePicker: new. Times at a fixed step in the reader's clock, on Select's groove and sheet.
- TreeView: new. Nested rows with a turning chevron and the chosen pane; the WAI-ARIA tree keys and type-ahead.
- Carousel: new. Slides that snap and never move by themselves, with buttons and dots.
- VirtualList: new. Draws only the rows in view, each with its place in the whole list.
- TransferList: new. Two Listboxes with move buttons that say how many they move.
- DataGrid: new. Table as a grid with one tab stop, cell keys, chosen rows and a sticky name column.
- BarChart: new. Thin bars from one baseline in the data palette (D-031), with a legend, labels and a table view.
- LineChart: new. 2px lines with end labels and a crosshair; never a second axis.
- Sparkline: new. A small trend in the secondary tone, with its trend said in words.
- Heatmap: new. One hue from faint to full with a 2px gap and a scale.
- Form: new. One column of fields with an error summary that takes focus after a failed submit and links to each field.
- Wizard: new. Stepper, one panel at a time under a heading that takes focus, Back and the loud Next last.
- AuthForm: new. Sign in, sign up and reset with the autocomplete names password managers need.
- CommandPalette: new. ⌘K opens a level-3 pane with grouped commands; focus stays in the field.
- NotificationCenter: new. A bell with the unread count and notices grouped by day; unread says New.
- CoachMark: new. A level-4 card anchored to one thing, with Next and Skip tour and no scrim.
- KanbanBoard: new. Cards that move by drag and by keyboard, every move said aloud.
- Feed: new. A WAI-ARIA feed that loads more near the end and says when it is done.
- AppShell: new. Header, sidebar or bottom bar by its own width, and a skip link.
- SettingsLayout: new. Groups of rows with a name, a sentence and the control at the end.
- RichTextEditor: new. A few marks over Input's groove, each saying when it is on; paste arrives plain.
- CommandPalette and CoachMark have a preview prop for docs, like the wave 4 overlays.
- Dialog: new. A level-3 pane over a scrim (D-025) on Radix Dialog; `actions`, `size`, `Dialog.Close`, `preview` for documentation.
- Sheet: new. A level-3 pane from the bottom, start or end; a grabber drags a bottom sheet closed.
- Drawer: new. A Sheet from the start or end edge.
- ActionSheet: new. Actions for one item from the bottom, Cancel set apart, the critical action last.
- Popover: new. A level-4 pane next to its trigger without a scrim.
- Tooltip: new. A few words on hover, focus and tap.
- Toast: new. A level-4 pane at the top end with a status mark, announced politely, pausing under the pointer.
- Snackbar: new. One line with Undo at the bottom of a phone screen.
- FAB: new. The loud bead at thumb reach, glowing strong in dark.
- PullToRefresh: new. Pull a list down to refresh it, with a Refresh button for keyboards (WCAG 2.5.1).
- Image: new. A picture with a corner from the scale that fades in over the carve and stays a quiet recess if it fails.

## 0.6.0 (2026-10-29)

- Mesh: new (D-029). A mesh gradient for covers, icons, illustrations and scenes, never a control's fill. Presets `aurora`, `ember`, `tide`, `dusk`; your own colours through `colors` and `base`, or the `--ds-mesh-*` variables; `rotate` turns the light; `glow` adds an ambient shadow in the mesh's colours; `label` names it as an image.
- Mesh: `npx pane-mesh --from brand.png` (or `--colors`) writes the `--ds-mesh-*` variables from a brand image and warns when a mesh would look flat. PNG only.
- Glow in dark (D-027): `glow.strong`, `glow.soft`, `glow.mark`. Button `accent` and IconButton `loud` glow strong, Switch on and the Slider's filled channel soft, the fill slider's marker as a mark. Nothing glows in light, and text never glows.
- Slider: new `variant="fill"`, a 56px bar held whole with its label and value inside (D-026). Both variants keep a width of their own (at least 240px) and never resize with their value text. The fill bar is a groove with the field's edge, so a full bar still shows where it ends in light.
- InputGroup: text at the end keeps the field's full inset; only a lone round button sits close to the curve.
- Select: disabled uses the `opacity.disabled` token.
- Field edges: a 1px edge all round carries the 3:1 instead of a thick white bottom lip.
- Tokens: `size.control-xl`, `size.slider-min`, `slider.fill-*`, `slider.min-width`, `slider.range-glow`, `glow.*`, `mesh.*`, `mesh-ember.*`, `mesh-tide.*`, `mesh-dusk.*`, `mesh-blur`, `mesh-glow-opacity`, `studio.*`, `color.ink.950`.

## 0.5.0 (2026-10-29)

- Thick smoked glass (D-025). A pane is a slab: a smoked body, a faint edge all round, shade at its foot, a short streak where light catches its top edge, and a long soft shadow. The loud solid is a warm off-white with a bloom.
- Levels. `Card` takes `level` 1 to 4 (pane, surface inside a pane, overlay, popover); a Card inside a Card is level 2 by itself, with no second blur and an inner corner. Use `--ds-card-scrim` under an overlay. Each level is measured at least 1.15:1 from what is under it.
- IconButton: new `loud` variant, a white bead.
- Slider: the thumb is a capsule and the track is thinner.
- Tabs: the track is a well and the chosen tab is grey glass.
- The book: a palette with full ramps (50 to 950) and roles in tabs on the Colour page; a grouped, searchable token reference; long sections fold behind their headings, so no page is longer than about ten screens.
- One light from above on every part (D-024, R-012). Every surface, control and track carries a rim brightest along its top edge, a sheen on its upper half and a short soft shadow; recesses are the inverse.
- No blue. `Button` `accent` is the loud solid glowing with its own light (white in dark, ink in light). Tabs, Switch, Slider and the Select check are monochrome: a chosen tab is a lighter pane of glass, a switch that is on is a lit track, the slider fills with the loud solid.
- Chip: chosen is a lighter pane with a check, the same chosen glass as Tabs.
- Button `glass`, IconButton and Chip rest on a short soft shadow and are lit from above.
- Tokens: `action.accent` and friends now resolve to the loud solid; new `surface.lit-*`, `elevation.track`, `elevation.loud-glow`, `elevation.quiet-cast`, `elevation.chosen-cast`, `elevation.on-glow`; `line.rim-*` describe a rim lit from above.

## 0.4.0 (2026-10-28)

- IconButton: a small round pane with Button's material (gloss, rim, pointer glint); quiet, so it no longer lifts on hover. A 44px press area around both sizes.
- Tabs: a carved track; the chosen tab is the blue accent sheet and slides to the tab the reader picks. Unchosen tabs lose their rings (D-023). A 44px press area on every tab.
- Chip: off is a small glass pane; chosen is pressed into the glass with a check and a heavier weight, so chosen chips add no loud marks. A 44px press area.
- Tag: etched into the glass instead of ringed.
- Badge: no fill. Each status tone has its own glyph shape in its colour and the word in the text colour. `dot` now applies to neutral only.
- Avatar: a portrait behind a lens with the pane's rim of light; the white ring on `lg` is replaced by a soft shadow.
- Slider: a carved channel filled with blue to the value, and the Switch's lit bead as the thumb, with a 44px press area on the thumb.
- Button, Select: a 44px press area at the small size too. Input `sm` is the one exception (E-002).
- Tokens: removed `badge.*-bg`, `badge.*-fg`, `badge.neutral-ring`, `tabs.ring`, `chip.ring`, `tag.ring`, `avatar.ring`, `avatar.ring-width`, `slider.track-ring`; added the etch, portrait and press-area tokens.
- Button: redrawn as a small pane (round 2, R-010). The fill is a sheet lit at its top and shaded at its foot, with the pane's own rim, a glint that follows the pointer, and a blue shadow under the accent. Only the loud kinds lift; a press tightens the shadow.
- Switch: a recess carved into the glass with a lit bead (R-007). A press squashes the bead toward its travel.
- Input, Textarea, InputGroup, PinInput: a groove with a lit bottom lip whose edge measures at least 3:1 on glass and on plain pages in both themes (R-009). A search field no longer disappears on white.
- Checkbox, Radio: the box is a carved recess with a 3:1 edge.
- Select: the trigger is Input's groove; the open list's rows nest the sheet corner (radius = sheet radius minus the even 6px inset), are 44px tall, the highlighted row is a lit lens with a pointer glint, and the check leads the chosen row (R-008).
- Tokens: `elevation.cast*`, `elevation.bead`, `elevation.carve*`, `elevation.groove`, `elevation.lens`, `surface.carve`, `surface.knob-shade`, `line.edge`, `action.gloss*`, `action.glint*`, `action.accent-foot`, `action.solid-top`, `action.foot-solid`, and the primitives behind them. `select.item-radius` is removed; the row radius is computed from `select.menu-radius` and `select.menu-inset`.
- Environment: `material="solid"` turns every pane inside opaque and switches the backdrop filter off, for live backdrops such as a 3D scene (D-021).
- Radio: an arrow key pressed and released at once now chooses the option it moves to, as a held key always did (scripted presses, switch devices and some screen readers).
- Checkbox: every prop documented.
- Switch: every prop documented.
- PinInput: every prop documented.

## 0.3.0 (2026-10-27)

- Input: First release, part of the W3 form family drawn as a well in the pane (D-020).
- Textarea: First release, part of the W3 form family drawn as a well in the pane (D-020).
- Checkbox: First release, part of the W3 form family drawn as a well in the pane (D-020).
- Radio: First release, part of the W3 form family drawn as a well in the pane (D-020).
- Switch: First release, part of the W3 form family drawn as a well in the pane (D-020).
- FormField: First release, part of the W3 form family drawn as a well in the pane (D-020).
- Label: First release, part of the W3 form family drawn as a well in the pane (D-020).
- HelperText: First release, part of the W3 form family drawn as a well in the pane (D-020).
- Fieldset: First release, part of the W3 form family drawn as a well in the pane (D-020).
- InputGroup: First release, part of the W3 form family drawn as a well in the pane (D-020).
- PinInput: First release, part of the W3 form family drawn as a well in the pane (D-020).
- Packaging: a semantic `opacity.disabled` token and `elevation.well`, used by every new form control.

## 0.2.0 (2026-10-27)

- Banner: Redrawn from the concept (derivation C, picked by the user) as a line written on the pane with a hairline, no box, no stripe and no tinted disc. Tones are glyph shapes, glyph colours and spoken words. Arriving and dismissing open and close its height. onDismiss now runs after the line has closed.
- Select: First release. The list is a Pane popup drawn from tokens with typeahead and full keyboard support, never the operating system menu.
- Slider: First release, with a visible label and value, a 44px hit area and a white knob that reads in both themes.
- Packaging: `pane-react/styles.css` and `pane-tokens/css` now ship type declarations, so `tsc` passes on TypeScript 6 and later, which check side-effect imports by default.

## 0.1.0 (2026-10-26)

- Environment: First release with three brightness levels. Dim and mid resolve to the bright value until they are calibrated (E-001).
- Card: First release with glass, inset and solid variants and a cover slot. Glass dims the photo behind it instead of greying it (D-010, D-011).
- Card: Light theme lifts and whitens the scene and sets ink text (D-015).
- Avatar: First release with photo, initials fallback and three sizes.
- Button: First release with light, accent and glass variants and the soft hover lift.
- Button: In the light theme the loud solid is ink with white text (D-015).
- IconButton: First release. The type now requires aria-label.
- Tabs: First release, built on Radix Tabs with pill styling.
- Tag: First release, outline small caps label.
- Container: First release with four widths and margins that grow at each breakpoint (D-014).
- Grid: First release with 4, 8 and 12 columns and per breakpoint spans (D-014).
- Stack: First release with row and column direction and the gap scale.
- Badge: First release with five tones and an optional dot.
- Chip: First release with toggle and input forms.
- Banner: First release with four tones, a live option and dismiss.
